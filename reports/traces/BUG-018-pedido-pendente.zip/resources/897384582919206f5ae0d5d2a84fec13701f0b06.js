import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{A as t,B as n,C as r,I as i,K as a,N as o,P as s,a as c,b as ee,f as te,h as ne,k as l,lt as u,m as re,n as d,o as f,p,r as m,s as ie,t as ae,u as h,x as g,z as _}from"./Referencia-D6jzv0vf.js";import{_ as oe,d as v,g as se,m as ce}from"./mercado-jVELtp4e.js";import{r as le}from"./index-C-tA94rF.js";import{n as ue,t as y}from"./tentativa-qaG5rCe1.js";var b=e(u(),1),x=`<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="Finalize sua seleção de NFTs na KURIO." />
  <title>Pagamento — KURIO</title>
  <!-- Tailwind CSS v4: todas as medidas e layouts ficam nas classes utilitárias. -->
  <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"><\/script>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@400;500;600;700&display=swap" rel="stylesheet" />
  <link rel="stylesheet" href="./index.css" />
  <style type="text/tailwindcss">
    @theme {
      --font-kurio: "Roboto Mono", monospace;
      --color-kurio-fundo: #150e0b;
      --color-kurio-texto: #f5f1eb;
      --color-kurio-secundaria: #ba9a7c;
      --color-kurio-destaque: #d9904b;
      --color-kurio-destaque-hover: #e6a15f;
      --color-kurio-borda: #36241c;
      --color-kurio-painel: #271914;
      --color-kurio-campo: #3b2517;
      --color-kurio-faixa: #3b2311;
      --color-kurio-escuro: #1c120e;
    }
  </style>
</head>
<body class="min-h-dvh bg-kurio-fundo font-kurio text-kurio-texto">
  <div class="pagina-pagamentos mx-auto w-full max-w-[1050px] px-8 max-[650px]:px-4">
    <!-- Cabeçalho e rodapé replicados da home/carrinho no protótipo.
         O Codex poderá extrair Header e Footer compartilhados no React. -->
    <header class="cabecalho flex h-[70px] items-center justify-between gap-6 border-b border-kurio-borda max-[500px]:gap-3">
<a class="logo text-[14px] font-bold tracking-[0.1em]" href="../index.html#inicio">
          KURIO
        </a>
<!-- MENU -->
<nav class="menu flex h-full items-center gap-10 max-[900px]:hidden">
<a class="link-menu inline-flex h-full items-center border-b-[3px] border-transparent text-[14px] transition-colors duration-150 hover:text-kurio-destaque data-[ativo=true]:border-kurio-destaque data-[ativo=true]:text-kurio-destaque focus-visible:outline-2 focus-visible:outline-kurio-destaque" data-ativo="false" href="../index.html#inicio">Início</a>
<a aria-current="page" class="link-menu inline-flex h-full items-center border-b-[3px] border-transparent text-[14px] transition-colors duration-150 hover:text-kurio-destaque data-[ativo=true]:border-kurio-destaque data-[ativo=true]:text-kurio-destaque focus-visible:outline-2 focus-visible:outline-kurio-destaque" data-ativo="true" href="../index.html#mercado">Mercado</a>
<a class="link-menu inline-flex h-full items-center border-b-[3px] border-transparent text-[14px] transition-colors duration-150 hover:text-kurio-destaque data-[ativo=true]:border-kurio-destaque data-[ativo=true]:text-kurio-destaque focus-visible:outline-2 focus-visible:outline-kurio-destaque" data-ativo="false" href="../index.html#criadores">Criadores</a>
<a class="link-menu inline-flex h-full items-center border-b-[3px] border-transparent text-[14px] transition-colors duration-150 hover:text-kurio-destaque data-[ativo=true]:border-kurio-destaque data-[ativo=true]:text-kurio-destaque focus-visible:outline-2 focus-visible:outline-kurio-destaque" data-ativo="false" href="../index.html#aprenda">Aprenda</a>
</nav>
<button aria-controls="menu-mobile" aria-expanded="false" class="botao-menu-mobile hidden cursor-pointer items-center rounded border border-kurio-borda px-3 py-2 text-[13px] max-[900px]:inline-flex" id="botao-menu-mobile" type="button">
          Menu
        </button>
<!-- ÍCONES E ENTRAR -->
<div class="acoes-cabecalho flex items-center gap-5 max-[500px]:gap-3">
<button aria-label="Buscar" type="button">
<svg fill="none" height="22" stroke="currentColor" stroke-linecap="round" stroke-width="1.8" viewbox="0 0 24 24" width="22">
<circle cx="11" cy="11" r="7"></circle>
<path d="m20 20-4-4"></path>
</svg>
</button>
<button aria-label="Carrinho com 0 itens" class="botao-carrinho relative inline-flex cursor-pointer items-center justify-center" id="abrir-carrinho" type="button">
<svg fill="none" height="23" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" viewbox="0 0 24 24" width="23">
<circle cx="9" cy="21" r="1"></circle>
<circle cx="20" cy="21" r="1"></circle>
<path d="M1 1h4l2.7 13.4a2 2 0 0 0 2 1.6h9.7a2 2 0 0 0 2-1.6L23 6H6"></path>
</svg>
<span aria-live="polite" class="indicador-carrinho absolute -right-2 -top-2 flex h-[18px] min-w-[18px] items-center justify-center rounded-full bg-kurio-destaque px-1 text-[10px] font-bold leading-none text-kurio-fundo" id="quantidade-carrinho">0</span>
</button>
<button class="botao-entrar inline-flex cursor-pointer items-center gap-2 rounded-md bg-kurio-destaque px-4 py-2 text-[13px] font-semibold text-kurio-fundo transition-colors hover:bg-kurio-destaque-hover max-[500px]:px-[10px]" type="button">
<svg fill="none" height="16" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewbox="0 0 24 24" width="16">
<path d="M10 17l5-5-5-5"></path>
<path d="M15 12H3"></path>
<path d="M12 3h7a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-7"></path>
</svg>
            Entrar
          </button>
</div>
</header>
    <nav aria-label="Menu para celular" class="menu-mobile hidden flex-col gap-1 border-b border-kurio-borda bg-kurio-painel p-3 min-[901px]:hidden" hidden="" id="menu-mobile">
<a class="menu-mobile-link rounded px-3 py-2 text-[13px] hover:bg-kurio-campo" href="../index.html#inicio">Início</a>
<a class="menu-mobile-link rounded px-3 py-2 text-[13px] hover:bg-kurio-campo" href="../index.html#mercado">Mercado</a>
<a class="menu-mobile-link rounded px-3 py-2 text-[13px] hover:bg-kurio-campo" href="../index.html#criadores">Criadores</a>
<a class="menu-mobile-link rounded px-3 py-2 text-[13px] hover:bg-kurio-campo" href="../index.html#aprenda">Aprenda</a>
</nav>

    <main id="pagina-pagamentos" class="pt-7 pb-[95px] max-[650px]:pb-14">
      <nav aria-label="Você está aqui" class="mb-[30px] flex items-center gap-2 text-[12px] font-semibold">
        <a href="../index.html#inicio" class="hover:text-kurio-destaque">Início</a><span>/</span>
        <a href="../index.html#mercado" class="hover:text-kurio-destaque">Mercado</a><span>/</span>
        <span aria-current="page">Pagamento</span>
      </nav>

      <div class="grid grid-cols-[minmax(0,1.9fr)_minmax(290px,1fr)] items-start gap-6 max-[820px]:grid-cols-1 max-[820px]:gap-12">
        <!-- PERFIL DO COLECIONADOR -->
        <section aria-labelledby="pagamentos-titulo-perfil" class="min-w-0">
          <h1 id="pagamentos-titulo-perfil" class="mb-3 text-[15px] font-bold tracking-[0.01em]">Perfil do colecionador</h1>
          <form id="pagamentos-formulario" class="grid grid-cols-2 gap-x-[18px] gap-y-[14px] max-[600px]:grid-cols-1" novalidate>

            <label class="flex min-w-0 flex-col gap-[5px] text-[11px]">Nome de exibição <span class="text-kurio-destaque">*</span>
              <input id="pagamentos-nome-exibicao" name="nomeExibicao" type="text" required minlength="2" autocomplete="nickname" class="pagamentos-campo h-[38px] w-full rounded-[3px] border border-kurio-borda bg-transparent px-3 text-[12px] outline-none transition-colors focus:border-kurio-destaque focus:ring-1 focus:ring-kurio-destaque" />
            </label>
            <label class="flex min-w-0 flex-col gap-[5px] text-[11px]">Nome de usuário <span class="text-kurio-destaque">*</span>
              <input id="pagamentos-usuario" name="usuario" type="text" required minlength="3" autocomplete="username" class="pagamentos-campo h-[38px] w-full rounded-[3px] border border-kurio-borda bg-transparent px-3 text-[12px] outline-none focus:border-kurio-destaque focus:ring-1 focus:ring-kurio-destaque" />
            </label>

            <label class="flex min-w-0 flex-col gap-[5px] text-[11px]">Rede <span class="text-kurio-destaque">*</span>
              <select id="pagamentos-rede" name="rede" required class="pagamentos-campo h-[38px] w-full cursor-pointer rounded-[3px] border border-kurio-borda bg-kurio-fundo px-3 text-[11px] text-kurio-secundaria outline-none focus:border-kurio-destaque focus:ring-1 focus:ring-kurio-destaque">
                <option value="">Selecione uma rede</option>
                <option value="Ethereum">Ethereum</option>
                <option value="Polygon">Polygon</option>
                <option value="Solana">Solana</option>
              </select>
            </label>
            <label class="flex min-w-0 flex-col gap-[5px] text-[11px]">Nome do perfil <span class="text-kurio-destaque">*</span>
              <input id="pagamentos-nome-perfil" name="nomePerfil" type="text" required minlength="2" class="pagamentos-campo h-[38px] w-full rounded-[3px] border border-kurio-borda bg-transparent px-3 text-[12px] outline-none focus:border-kurio-destaque focus:ring-1 focus:ring-kurio-destaque" />
            </label>

            <label class="flex min-w-0 flex-col gap-[5px] text-[11px]">Endereço da carteira <span class="text-kurio-destaque">*</span>
              <input id="pagamentos-carteira-endereco" name="carteiraEndereco" type="text" required autocomplete="off" placeholder="Endereço 0x da carteira" class="pagamentos-campo h-[38px] w-full rounded-[3px] border border-kurio-borda bg-transparent px-3 text-[11px] outline-none placeholder:text-[#ad8655] focus:border-kurio-destaque focus:ring-1 focus:ring-kurio-destaque" />
            </label>
            <label class="flex min-w-0 flex-col gap-[5px] text-[11px]">ENS ou carteira secundária (opcional)
              <input id="pagamentos-carteira-secundaria" name="carteiraSecundaria" type="text" placeholder="ENS ou carteira secundária" class="pagamentos-campo h-[38px] w-full rounded-[3px] border border-kurio-borda bg-transparent px-3 text-[11px] outline-none placeholder:text-[#ad8655] focus:border-kurio-destaque focus:ring-1 focus:ring-kurio-destaque" />
            </label>

            <label class="flex min-w-0 flex-col gap-[5px] text-[11px]">Tipo de carteira <span class="text-kurio-destaque">*</span>
              <select id="pagamentos-carteira-tipo" name="carteiraTipo" required class="pagamentos-campo h-[38px] w-full cursor-pointer rounded-[3px] border border-kurio-borda bg-kurio-fundo px-3 text-[11px] text-kurio-secundaria outline-none focus:border-kurio-destaque focus:ring-1 focus:ring-kurio-destaque">
                <option value="">Selecione uma carteira</option>
                <option value="MetaMask">MetaMask</option>
                <option value="WalletConnect">WalletConnect</option>
                <option value="Coinbase Wallet">Coinbase Wallet</option>
              </select>
            </label>
            <label class="flex min-w-0 flex-col gap-[5px] text-[11px]">Código de indicação <span class="text-kurio-destaque">*</span>
              <input id="pagamentos-indicacao" name="indicacao" type="text" required class="pagamentos-campo h-[38px] w-full rounded-[3px] border border-kurio-borda bg-transparent px-3 text-[12px] outline-none focus:border-kurio-destaque focus:ring-1 focus:ring-kurio-destaque" />
            </label>

            <label class="flex min-w-0 flex-col gap-[5px] text-[11px]">E-mail <span class="text-kurio-destaque">*</span>
              <input id="pagamentos-email" name="email" type="email" required autocomplete="email" class="pagamentos-campo h-[38px] w-full rounded-[3px] border border-kurio-borda bg-transparent px-3 text-[12px] outline-none focus:border-kurio-destaque focus:ring-1 focus:ring-kurio-destaque" />
            </label>
            <label class="flex min-w-0 flex-col gap-[5px] text-[11px]">Nome ENS <span class="text-kurio-destaque">*</span>
              <span class="flex h-[38px] w-fit min-w-[95px] overflow-hidden rounded-[3px] border border-kurio-borda focus-within:border-kurio-destaque focus-within:ring-1 focus-within:ring-kurio-destaque">
                <input id="pagamentos-ens" name="ens" required type="text" placeholder="nome" aria-label="Nome ENS sem o sufixo .eth" class="w-[65px] min-w-0 bg-transparent pl-2 text-[11px] outline-none placeholder:text-[#ad8655]" />
                <span class="flex items-center pr-2 text-[11px] text-kurio-secundaria">.eth</span>
              </span>
            </label>

            <div class="col-span-2 mt-2 max-[600px]:col-span-1">
              <label class="inline-flex cursor-pointer items-center gap-2 text-[11px]">
                <input id="pagamentos-outra-carteira" type="checkbox" class="peer sr-only" />
                <span aria-hidden="true" class="flex h-[13px] w-[13px] items-center justify-center rounded-full border border-kurio-destaque peer-checked:bg-kurio-destaque peer-focus-visible:outline-2 peer-focus-visible:outline-kurio-destaque"><span class="hidden h-[5px] w-[5px] rounded-full bg-kurio-fundo peer-checked:block"></span></span>
                Usar outra carteira?
              </label>
              <div id="pagamentos-carteira-extra-bloco" class="mt-3 hidden" hidden>
                <label for="pagamentos-carteira-extra" class="mb-1 block text-[11px]">Endereço da outra carteira</label>
                <input id="pagamentos-carteira-extra" type="text" placeholder="Endereço 0x da outra carteira" class="h-[38px] w-full max-w-[360px] rounded-[3px] border border-kurio-borda bg-transparent px-3 text-[11px] outline-none focus:border-kurio-destaque" />
              </div>
            </div>
            <label class="col-span-2 flex flex-col gap-2 text-[11px] max-[600px]:col-span-1">Observação do colecionador (opcional)
              <textarea id="pagamentos-observacao" name="observacao" rows="6" class="pagamentos-campo min-h-[145px] w-full max-w-[328px] resize-y rounded-[3px] border border-kurio-borda bg-transparent px-3 py-2 text-[12px] outline-none focus:border-kurio-destaque"></textarea>
            </label>
          </form>
        </section>

        <!-- RESUMO DOS NFTs / PAGAMENTO -->
        <aside aria-labelledby="pagamentos-titulo-resumo" class="min-w-0">
          <h2 id="pagamentos-titulo-resumo" class="mb-[6px] text-[15px] font-bold">Seus NFTs</h2>
          <div class="grid grid-cols-[minmax(0,1fr)_auto] border-b border-kurio-borda pb-[7px] text-[12px] font-semibold"><span>NFTs</span><span>Subtotal</span></div>
          <div id="pagamentos-itens" class="flex flex-col gap-2 pt-[9px]"></div>
          <div id="pagamentos-sem-itens" class="hidden py-7 text-[12px] leading-6 text-kurio-secundaria">Nenhum NFT no carrinho. <a class="underline hover:text-kurio-destaque" href="../index.html#mercado">Explorar produtos</a>.</div>
          <button id="pagamentos-abrir-cupom" type="button" class="mt-[12px] block w-full cursor-pointer text-center text-[11px] hover:text-kurio-destaque">Tem um código promocional? Aplique aqui</button>
          <form id="pagamentos-formulario-cupom" class="mt-2 hidden gap-2" hidden>
            <input id="pagamentos-cupom" class="h-[33px] min-w-0 flex-1 rounded border border-kurio-borda bg-kurio-campo px-2 text-[11px] outline-none focus:border-kurio-destaque" aria-label="Código promocional" placeholder="Código promocional" />
            <button type="submit" class="rounded bg-kurio-destaque px-3 text-[11px] font-bold text-kurio-fundo hover:bg-kurio-destaque-hover">Aplicar</button>
          </form>
          <p id="pagamentos-mensagem-cupom" aria-live="polite" class="mt-1 min-h-[14px] text-[10px] text-kurio-secundaria"></p>
          <dl class="mt-2 flex flex-col gap-[13px] text-[12px] max-[500px]:text-[11px]">
            <div class="flex justify-between gap-3"><dt>Subtotal</dt><dd id="pagamentos-subtotal" class="whitespace-nowrap">0.00 ETH</dd></div>
            <div class="flex justify-between gap-3"><dt>Desconto do lançamento</dt><dd id="pagamentos-desconto" class="whitespace-nowrap">(-) 0.00 ETH</dd></div>
            <div class="flex justify-between gap-3"><dt>Taxa de rede</dt><dd id="pagamentos-taxa" class="whitespace-nowrap">0.016 ETH</dd></div>
            <p class="-mt-2 text-right text-[10px] text-kurio-destaque">Taxa estimada</p>
          </dl>
          <div class="mt-4 flex justify-between gap-3 border-t border-kurio-borda pt-3 text-[14px] font-bold"><span>Total</span><strong id="pagamentos-total" class="whitespace-nowrap text-kurio-destaque">0.000 ETH</strong></div>
          <h3 class="mt-2 mb-[11px] text-center text-[14px] font-bold">Carteira e rede</h3>

          <fieldset id="pagamentos-carteiras" class="flex flex-col gap-3" aria-label="Escolha de carteira">
            <legend class="sr-only">Escolha a carteira</legend>
            <label class="flex min-h-[42px] cursor-pointer items-center gap-2 rounded-[3px] border border-kurio-borda px-3 text-[11px] hover:border-kurio-destaque has-[:checked]:border-kurio-destaque">
              <input type="radio" name="pagamentos-radio-carteira" value="WalletConnect" class="accent-[#D9904B]" />
              <span class="rounded bg-kurio-campo px-2 py-1 text-[9px] font-bold text-kurio-destaque">METAMASK · WALLETCONNECT · COINBASE</span>
            </label>
            <label class="flex min-h-[42px] cursor-pointer items-center gap-2 rounded-[3px] border border-kurio-borda px-3 text-[11px] hover:border-kurio-destaque has-[:checked]:border-kurio-destaque">
              <input type="radio" name="pagamentos-radio-carteira" value="MetaMask" class="accent-[#D9904B]" />
              MetaMask
            </label>
            <label class="flex min-h-[42px] cursor-pointer items-center gap-2 rounded-[3px] border border-kurio-borda px-3 text-[11px] hover:border-kurio-destaque has-[:checked]:border-kurio-destaque">
              <input type="radio" name="pagamentos-radio-carteira" value="Coinbase Wallet" class="accent-[#D9904B]" checked />
              Coinbase Wallet
            </label>
          </fieldset>
          <button id="pagamentos-confirmar" type="submit" form="pagamentos-formulario" class="mt-[22px] w-full cursor-pointer rounded-[5px] bg-kurio-destaque px-3 py-[12px] text-[13px] font-bold text-kurio-fundo hover:bg-kurio-destaque-hover focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-kurio-destaque disabled:cursor-not-allowed disabled:opacity-40">Confirmar compra</button>
          <p id="pagamentos-retorno" role="status" aria-live="polite" class="mt-3 hidden rounded-[4px] border border-kurio-destaque/50 bg-kurio-painel p-3 text-[11px] leading-5 text-kurio-secundaria"></p>
          <a id="pagamentos-ver-demo" href="../confirmacao-pedido/index.html?demo=1" class="mt-3 hidden text-center text-[11px] text-kurio-destaque underline hover:text-kurio-destaque-hover">Visualizar confirmação de demonstração (sem pagamento real)</a>
        </aside>
      </div>
    </main>
    <footer class="rodape-kurio w-full overflow-hidden bg-kurio-painel font-kurio text-kurio-texto">
<!-- PRIMEIRA LINHA: BENEFÍCIOS E NEWSLETTER -->
<div class="rodape-kurio-superior grid grid-cols-[1fr_1fr_1fr_1.35fr] gap-0 px-7 pt-7 pb-5 max-[900px]:grid-cols-2 max-[900px]:gap-y-[25px] max-[550px]:grid-cols-1 max-[550px]:gap-y-[25px] max-[550px]:p-5">
<!-- BENEFÍCIO 1 -->
<div class="rodape-kurio-beneficio border-r border-[#9e6534] pr-[18px] pl-3 max-[550px]:border-r-0 max-[550px]:border-b max-[550px]:pb-5 max-[550px]:pl-0">
<div class="rodape-kurio-circulo mb-3 flex h-[54px] w-[54px] items-center justify-center rounded-full bg-kurio-destaque text-[18px] font-bold text-kurio-fundo">
              W
            </div>
<h3 class="rodape-kurio-titulo-beneficio mb-2 text-[13px] leading-[1.4] font-bold">
              Segurança da carteira
            </h3>
<p class="rodape-kurio-descricao-beneficio text-[11px] leading-[1.55] text-kurio-secundaria">
              Proteja sua carteira e colecione arte digital verificada com
              confiança.
            </p>
</div>
<!-- BENEFÍCIO 2 -->
<div class="rodape-kurio-beneficio border-r border-[#9e6534] pr-[18px] pl-3 max-[550px]:border-r-0 max-[550px]:border-b max-[550px]:pb-5 max-[550px]:pl-0">
<div class="rodape-kurio-circulo mb-3 flex h-[54px] w-[54px] items-center justify-center rounded-full bg-kurio-destaque text-[18px] font-bold text-kurio-fundo">
              C
            </div>
<h3 class="rodape-kurio-titulo-beneficio mb-2 text-[13px] leading-[1.4] font-bold">
              Criadores em destaque
            </h3>
<p class="rodape-kurio-descricao-beneficio text-[11px] leading-[1.55] text-kurio-secundaria">
              Conheça artistas, estúdios e comunidades que moldam a cultura
              digital na rede.
            </p>
</div>
<!-- BENEFÍCIO 3 -->
<div class="rodape-kurio-beneficio border-r border-[#9e6534] pr-[18px] pl-3 max-[550px]:border-r-0 max-[550px]:border-b max-[550px]:pb-5 max-[550px]:pl-0">
<div class="rodape-kurio-circulo mb-3 flex h-[54px] w-[54px] items-center justify-center rounded-full bg-kurio-destaque text-[18px] font-bold text-kurio-fundo">
              D
            </div>
<h3 class="rodape-kurio-titulo-beneficio mb-2 text-[13px] leading-[1.4] font-bold">
              Alertas de lançamentos
            </h3>
<p class="rodape-kurio-descricao-beneficio text-[11px] leading-[1.55] text-kurio-secundaria">
              Receba calendários de cunhagem, novidades de listas de acesso e
              análises de mercado.
            </p>
</div>
<!-- NEWSLETTER -->
<div class="rodape-kurio-newsletter min-w-0 pl-4 max-[900px]:border-l max-[900px]:border-[#9e6534] max-[550px]:border-0 max-[550px]:pl-0">
<h3 class="rodape-kurio-titulo-newsletter mb-3 text-[13px] leading-[1.2] font-bold">
              Antecipe-se ao próximo lançamento
            </h3>
<form class="rodape-kurio-formulario mb-3 flex h-[34px] w-full">
<input aria-label="Seu e-mail" class="rodape-kurio-campo-email min-w-0 flex-1 rounded-l-[5px] border-none bg-kurio-campo px-[10px] text-[11px] text-kurio-texto outline-none placeholder:text-[#a88661] focus:ring-1 focus:ring-kurio-destaque" placeholder="digite seu e-mail..." required="" type="email"/>
<button class="rodape-kurio-botao-enviar shrink-0 cursor-pointer rounded-r-[5px] bg-kurio-destaque px-[15px] text-[12px] font-bold text-kurio-fundo hover:bg-kurio-destaque-hover" type="submit">
                Enviar
              </button>
</form>
<p class="rodape-kurio-texto-newsletter text-[10px] leading-[1.7] text-kurio-secundaria">
              Receba lançamentos selecionados, histórias de criadores e
              novidades do mercado.
            </p>
</div>
</div>
<!-- =====================================
       SEGUNDA LINHA: INFORMAÇÕES DA EMPRESA
  ===================================== -->
<div class="rodape-kurio-informacoes grid min-h-[65px] grid-cols-4 items-center gap-5 bg-kurio-faixa px-7 py-[15px] max-[900px]:grid-cols-2 max-[550px]:grid-cols-1 max-[550px]:gap-3 max-[550px]:p-5">
<p class="rodape-kurio-marca text-[12px] font-bold tracking-[0.06em]">
            KURIO
          </p>
<p class="rodape-kurio-frase text-[11px] leading-[1.6]">
            Feito para colecionadores, criadores e cultura
          </p>
<a class="rodape-kurio-contato break-words text-[11px] text-kurio-texto hover:text-kurio-destaque" href="mailto:contato@email.com">
            contato@email.com
          </a>
<a class="rodape-kurio-contato break-words text-[11px] text-kurio-texto hover:text-kurio-destaque" href="tel:+551140028922">
            +55 11 4002 8922
          </a>
</div>
<!-- =====================================
       TERCEIRA LINHA: LINKS E REDES SOCIAIS
  ===================================== -->
<div class="rodape-kurio-links grid grid-cols-4 gap-[25px] px-7 pt-[27px] pb-[30px] max-[900px]:grid-cols-2 max-[900px]:gap-[35px] max-[550px]:gap-x-[15px] max-[550px]:gap-y-[30px] max-[550px]:px-5 max-[550px]:py-[25px]">
<!-- MEU PERFIL -->
<div class="rodape-kurio-coluna flex min-w-0 flex-col">
<h3 class="rodape-kurio-titulo-coluna mb-3 text-[14px] font-bold max-[550px]:text-[12px]">
              Meu perfil
            </h3>
<nav class="rodape-kurio-lista-links flex flex-col items-start gap-[11px]">
<a class="text-[11px] leading-[1.3] text-kurio-texto hover:text-kurio-destaque max-[550px]:text-[10px]" href="#">Meu perfil</a>
<a class="text-[11px] leading-[1.3] text-kurio-texto hover:text-kurio-destaque max-[550px]:text-[10px]" href="#">Minha coleção</a>
<a class="text-[11px] leading-[1.3] text-kurio-texto hover:text-kurio-destaque max-[550px]:text-[10px]" href="#">Atividade</a>
<a class="text-[11px] leading-[1.3] text-kurio-texto hover:text-kurio-destaque max-[550px]:text-[10px]" href="#">Estúdio do criador</a>
<a class="text-[11px] leading-[1.3] text-kurio-texto hover:text-kurio-destaque max-[550px]:text-[10px]" href="#">Lista de interesse</a>
</nav>
</div>
<!-- CENTRAL DE AJUDA -->
<div class="rodape-kurio-coluna flex min-w-0 flex-col">
<h3 class="rodape-kurio-titulo-coluna mb-3 text-[14px] font-bold max-[550px]:text-[12px]">
              Central de ajuda
            </h3>
<nav class="rodape-kurio-lista-links flex flex-col items-start gap-[11px]">
<a class="text-[11px] leading-[1.3] text-kurio-texto hover:text-kurio-destaque max-[550px]:text-[10px]" href="#">Central de ajuda</a>
<a class="text-[11px] leading-[1.3] text-kurio-texto hover:text-kurio-destaque max-[550px]:text-[10px]" href="#">Como comprar NFTs</a>
<a class="text-[11px] leading-[1.3] text-kurio-texto hover:text-kurio-destaque max-[550px]:text-[10px]" href="#">Carteira e segurança</a>
<a class="text-[11px] leading-[1.3] text-kurio-texto hover:text-kurio-destaque max-[550px]:text-[10px]" href="#">Política do mercado</a>
<a class="text-[11px] leading-[1.3] text-kurio-texto hover:text-kurio-destaque max-[550px]:text-[10px]" href="#">Denunciar item</a>
</nav>
</div>
<!-- COLEÇÕES -->
<div class="rodape-kurio-coluna flex min-w-0 flex-col">
<h3 class="rodape-kurio-titulo-coluna mb-3 text-[14px] font-bold max-[550px]:text-[12px]">
              Coleções
            </h3>
<nav class="rodape-kurio-lista-links flex flex-col items-start gap-[11px]">
<a class="text-[11px] leading-[1.3] text-kurio-texto hover:text-kurio-destaque max-[550px]:text-[10px]" href="#">Arte digital</a>
<a class="text-[11px] leading-[1.3] text-kurio-texto hover:text-kurio-destaque max-[550px]:text-[10px]" href="#">Fotografia</a>
<a class="text-[11px] leading-[1.3] text-kurio-texto hover:text-kurio-destaque max-[550px]:text-[10px]" href="#">Música</a>
<a class="text-[11px] leading-[1.3] text-kurio-texto hover:text-kurio-destaque max-[550px]:text-[10px]" href="#">Arte 3D</a>
<a class="text-[11px] leading-[1.3] text-kurio-texto hover:text-kurio-destaque max-[550px]:text-[10px]" href="#">Utilidade</a>
</nav>
</div>
<!-- REDES SOCIAIS -->
<div class="rodape-kurio-coluna flex min-w-0 flex-col">
<h3 class="rodape-kurio-titulo-coluna mb-3 text-[14px] font-bold max-[550px]:text-[12px]">
              Redes sociais
            </h3>
<div class="rodape-kurio-redes flex flex-wrap gap-[6px]">
<!-- FACEBOOK -->
<a aria-label="Facebook" class="rodape-kurio-icone-social flex h-[25px] w-[25px] items-center justify-center rounded-[4px] border border-kurio-destaque text-kurio-destaque transition-colors hover:bg-kurio-destaque hover:text-kurio-fundo" href="#">
<svg aria-hidden="true" class="h-[15px] w-[15px] fill-current" viewbox="0 0 24 24">
<path d="M15 3h-3a4 4 0 0 0-4 4v3H5v4h3v7h4v-7h3l1-4h-4V7h3V3z"></path>
</svg>
</a>
<!-- INSTAGRAM -->
<a aria-label="Instagram" class="rodape-kurio-icone-social flex h-[25px] w-[25px] items-center justify-center rounded-[4px] border border-kurio-destaque text-kurio-destaque transition-colors hover:bg-kurio-destaque hover:text-kurio-fundo" href="#">
<svg aria-hidden="true" class="h-[15px] w-[15px] fill-current" viewbox="0 0 24 24">
<rect fill="none" height="18" rx="5" stroke="currentColor" stroke-width="2" width="18" x="3" y="3"></rect>
<circle cx="12" cy="12" fill="none" r="4" stroke="currentColor" stroke-width="2"></circle>
<circle cx="17.5" cy="6.5" r="1.2"></circle>
</svg>
</a>
<!-- TWITTER -->
<a aria-label="Twitter" class="rodape-kurio-icone-social flex h-[25px] w-[25px] items-center justify-center rounded-[4px] border border-kurio-destaque text-kurio-destaque transition-colors hover:bg-kurio-destaque hover:text-kurio-fundo" href="#">
<svg aria-hidden="true" class="h-[15px] w-[15px] fill-current" viewbox="0 0 24 24">
<path d="M22 5.9a8 8 0 0 1-2.3.6
                     4 4 0 0 0 1.8-2.2
                     8 8 0 0 1-2.6 1
                     4 4 0 0 0-6.8 3.6
                     11 11 0 0 1-8-4.1
                     4 4 0 0 0 1.2 5.3
                     4 4 0 0 1-1.8-.5
                     4 4 0 0 0 3.2 4
                     4 4 0 0 1-1.8.1
                     4 4 0 0 0 3.7 2.8
                     8 8 0 0 1-5 1.7
                     11 11 0 0 0 17-9.3
                     8 8 0 0 0 2-2z"></path>
</svg>
</a>
<!-- LINKEDIN -->
<a aria-label="LinkedIn" class="rodape-kurio-icone-social flex h-[25px] w-[25px] items-center justify-center rounded-[4px] border border-kurio-destaque text-kurio-destaque transition-colors hover:bg-kurio-destaque hover:text-kurio-fundo" href="#">
<svg aria-hidden="true" class="h-[15px] w-[15px] fill-current" viewbox="0 0 24 24">
<path d="M4 9v11M4 4v1M10 20V9h4v2
                     c1-2 6-3 6 3v6M10 14v6" fill="none" stroke="currentColor" stroke-linecap="round" stroke-width="2.5"></path>
</svg>
</a>
<!-- YOUTUBE -->
<a aria-label="YouTube" class="rodape-kurio-icone-social flex h-[25px] w-[25px] items-center justify-center rounded-[4px] border border-kurio-destaque text-kurio-destaque transition-colors hover:bg-kurio-destaque hover:text-kurio-fundo" href="#">
<svg aria-hidden="true" class="h-[15px] w-[15px] fill-current" viewbox="0 0 24 24">
<rect fill="none" height="14" rx="4" stroke="currentColor" stroke-width="2" width="20" x="2" y="5"></rect>
<path d="m10 9 5 3-5 3z"></path>
</svg>
</a>
</div>
<!-- CARTEIRAS -->
<div class="rodape-kurio-carteiras mt-[25px]">
<h3 class="rodape-kurio-titulo-coluna mb-3 text-[14px] font-bold max-[550px]:text-[12px]">
                Carteiras compatíveis
              </h3>
<div class="rodape-kurio-lista-carteiras inline-block max-w-full rounded-[4px] border border-[#604020] bg-kurio-campo px-[7px] py-[6px] text-[8px] leading-[1.3] font-bold text-kurio-destaque whitespace-normal">
                METAMASK · WALLETCONNECT · COINBASE
              </div>
</div>
</div>
</div>
<!-- =====================================
       ÚLTIMA LINHA: DIREITOS AUTORAIS
  ===================================== -->
<div class="rodape-kurio-direitos bg-kurio-escuro px-[15px] py-[13px] text-center text-[10px] tracking-[0.02em] max-[550px]:text-[9px]">
          © 2026 Kurio. Propriedade digital para todos.
        </div>
</footer>
  </div>

  <!-- Só os elementos de cada linha são clonados; as classes Tailwind permanecem estáticas no template. -->
  <template id="pagamentos-modelo-item">
    <article class="flex min-w-0 items-center justify-between gap-2 bg-kurio-painel p-[5px] max-[420px]:flex-wrap">
      <a data-pagamentos-link href="#" class="flex min-w-0 flex-1 items-center gap-2 hover:text-kurio-destaque focus-visible:outline-kurio-destaque">
        <img data-pagamentos-imagem src="../src/images/primeape1.png" alt="" class="h-[55px] w-[55px] shrink-0 rounded-[5px] object-cover max-[420px]:h-[48px] max-[420px]:w-[48px]" />
        <span class="min-w-0"><strong data-pagamentos-nome class="block truncate text-[11px] font-bold max-[420px]:text-[10px]"></strong><small data-pagamentos-token class="mt-1 block truncate text-[9px] text-kurio-secundaria"></small></span>
      </a>
      <span data-pagamentos-quantidade class="shrink-0 text-[10px] text-kurio-secundaria">(x 1)</span>
      <strong data-pagamentos-valor class="shrink-0 text-right text-[11px] font-bold text-kurio-destaque">0.00 ETH</strong>
    </article>
  </template>

  <!-- Modal de login já existente, chamado com o script compartilhado. -->
  <p id="pagamentos-aviso" aria-live="polite" role="status" class="pointer-events-none fixed right-5 bottom-5 z-[10000] hidden max-w-[410px] rounded border border-kurio-destaque bg-kurio-painel px-4 py-3 text-[12px] text-kurio-texto shadow-lg"></p>
  <script src="../login/abrir-login.js" defer><\/script>
  <script src="../carrinho/vincular-carrinho.js" defer><\/script>
  <script src="./interacoes.js" defer><\/script>
</body>
</html>
`,S=a(),C=m(`pagamentos`,x),de=c(C,`pagamentos-modelo-item`).children.find(e=>e.type===`tag`);function w(){let{sessao:e}=ee();return e&&(0,S.jsx)(T,{sessao:e},e.perfil.id)}function T({sessao:e}){let{avisar:a}=ee(),c=e.perfil.id,u=n(),m=i(r(c)),[x,w]=(0,b.useState)(``),[T,E]=(0,b.useState)(),[D,O]=(0,b.useState)(`Coinbase Wallet`),[k,A]=(0,b.useState)(),[j,M]=(0,b.useState)(!1),[N,fe]=(0,b.useState)(!1),[pe,P]=(0,b.useState)(``),[F,I]=(0,b.useState)({}),L=(0,b.useId)(),[me,R]=(0,b.useState)(!1),[z,B]=(0,b.useState)(),[V,H]=(0,b.useState)(()=>ue(c)),U=(0,b.useRef)(!1),W=m.data?.find(e=>e.id===x)??m.data?.[0],he=e=>e.length>22?e.slice(0,7)+`…`+e.slice(-4):e,G=T??W?.rede??`Ethereum`,K=i({queryKey:[`privado`,c,`cotacao`,G],queryFn:({signal:e})=>t.cotacao(G,e)}),q=i({queryKey:[`privado`,c,`pendente`],queryFn:({signal:e})=>t.pendente(e)}),J=le(),Y=s({mutationFn:t.conectar,onSuccess:e=>{A(e),a(`Carteira conectada.`)}}),X=s({mutationFn:t.desconectar,onSuccess:(e,t)=>{A(e=>e?.id===t?void 0:e)}});function ge(e){k&&(A(void 0),X.mutate(k.id)),w(e.id),E(e.rede)}let Z=s({mutationFn:e=>t.iniciarPedido(e.proposta,e.chave),onSuccess:async(t,n)=>{if(o()!==e.token)return;let r={...n,pedidoId:t.id};y(c,r),H(r),g.setQueryData([`privado`,c,`pedido`,t.id],t),await u({to:`/pedidos/$pedidoId`,params:{pedidoId:t.id}})},onError:t=>{if(o()!==e.token)return;let n=l(t);[`rede`,`timeout`,`sessao-invalida`].includes(n.codigo)||(y(c,null),H(null),B(void 0),n.cotacao&&g.setQueryData([`privado`,c,`cotacao`,n.cotacao.rede],n.cotacao),n.codigo===`carteira-desconectada`&&A(void 0),q.refetch())},onSettled:()=>{U.current=!1}});function _e(e){U.current||(U.current=!0,y(c,e),H(e),Z.mutate(e))}async function ve(e){if(e.preventDefault(),!K.data?.linhas.length||K.data.problemas.length||V||q.data||!W)return;let t=new FormData(e.currentTarget);if(P(``),I({}),String(N?t.get(`carteiraExtra`):t.get(`carteiraEndereco`)).trim().toLowerCase()!==W.endereco.toLowerCase()||W.rede!==G)P(`Escolha uma carteira cadastrada compatível com o endereço e a rede informados.`);else try{let e=k??await Y.mutateAsync({carteiraId:W.id,rede:G,provedor:D}),n=ce.safeParse({cotacaoId:K.data.id,conexaoId:e.id,rede:G,coletor:{nome:t.get(`nomeExibicao`),email:t.get(`email`),usuario:t.get(`usuario`),nomePerfil:t.get(`nomePerfil`),indicacao:t.get(`indicacao`),ens:t.get(`ens`),observacao:t.get(`observacao`)||void 0}});if(!n.success){I(Object.fromEntries(n.error.issues.filter(e=>e.path[0]===`coletor`).map(e=>[e.path[1]===`nome`?`nomeExibicao`:String(e.path[1]),e.message]))),P(`Revise os dados do perfil do colecionador.`);return}B({cotacao:K.data,proposta:n.data}),Z.reset()}catch{}}let Q=K.data,ye=!!z&&z.cotacao.id!==Q?.id,$=e.perfil,be={nomeExibicao:$.nome,usuario:$.usuario??$.email.split(`@`)[0],nomePerfil:$.nome,carteiraEndereco:W?.endereco,carteiraSecundaria:m.data?.find(e=>e.tipo===`secundaria`)?.endereco,indicacao:`KURIO`,email:$.email,ens:$.nomeEns??$.email.split(`@`)[0]},xe={"pagamentos-subtotal":v(Q?.subtotal??`0`),"pagamentos-desconto":`(-) `+v(Q?.desconto??`0`),"pagamentos-taxa":v(Q?.taxa??`0`),"pagamentos-total":v(Q?.total??`0`)};return(0,S.jsx)(ae,{pagina:C,alterar:(e,t,n)=>{let r=e.attribs.id,i=e.attribs.name;if(r===`pagina-pagamentos`)return d(e,{},(0,S.jsxs)(S.Fragment,{children:[(0,S.jsxs)(`header`,{className:`referencia-titulo-fluxo`,children:[(0,S.jsx)(_,{to:`/carrinho`,"aria-label":`Voltar ao carrinho`,children:`‹`}),(0,S.jsx)(`h1`,{children:`Pagamento com carteira`})]}),(0,S.jsxs)(`div`,{className:`checkout-mobile-carteiras`,children:[(0,S.jsxs)(`div`,{className:`checkout-mobile-titulo`,children:[(0,S.jsx)(`h2`,{children:`Carteira conectada`}),(0,S.jsx)(`button`,{type:`button`,onClick:()=>R(!0),children:`Trocar carteira`})]}),(0,S.jsx)(`fieldset`,{"aria-label":`Carteiras cadastradas`,children:[...m.data??[]].reverse().map(e=>(0,S.jsxs)(`label`,{children:[(0,S.jsx)(`input`,{type:`radio`,name:`escolher-carteira-mobile`,checked:W?.id===e.id,onChange:()=>ge(e)}),(0,S.jsxs)(`span`,{children:[(0,S.jsx)(`strong`,{children:e.nome}),(0,S.jsx)(`small`,{title:e.endereco,children:he(e.endereco)}),(0,S.jsxs)(`small`,{children:[`Rede `,e.rede]})]}),(0,S.jsx)(`span`,{className:`ml-auto self-center`,"aria-hidden":`true`,children:`⋮`})]},e.id))}),m.isSuccess&&!W&&(0,S.jsx)(_,{to:`/conta/carteiras`,children:`Cadastre uma carteira`})]}),n(),(0,S.jsxs)(`div`,{className:`checkout-gerenciar-carteira`,children:[(0,S.jsx)(`button`,{type:`button`,onClick:()=>R(!0),children:`Trocar carteira`}),k&&(0,S.jsx)(`button`,{type:`button`,onClick:()=>X.mutate(k.id),children:`Desconectar carteira`})]})]}));if(r&&Object.hasOwn(xe,r))return d(e,{},xe[r]);if(r===`pagamentos-formulario`)return d(e,{noValidate:!1,onSubmit:e=>void ve(e),key:W?.id??`perfil`},n());if(e.name===`input`&&i&&Object.hasOwn(be,i)){let t=F[i];return d(e,{defaultValue:be[i],"aria-invalid":t?!0:void 0,"aria-describedby":t?L+i:void 0})}if(r===`pagamentos-rede`)return d(e,{value:G,disabled:!!k,onChange:e=>{let t=oe.find(t=>t===e.target.value);if(!t)return;let n=m.data?.find(e=>e.rede===t);n&&w(n.id),E(t)}},n());if(r===`pagamentos-carteira-tipo`)return d(e,{value:D,disabled:!!k,onChange:e=>{let t=se.find(t=>t===e.target.value);t&&O(t)}},n());if(r===`pagamentos-outra-carteira`)return d(e,{checked:N,onChange:e=>fe(e.target.checked)});if(r===`pagamentos-carteira-extra-bloco`)return d(e,f(t,!N),n());if(r===`pagamentos-carteira-extra`)return d(e,{name:`carteiraExtra`,required:N,disabled:!N});if(r===`pagamentos-itens`)return d(e,{},(0,S.jsxs)(S.Fragment,{children:[K.isPending&&(0,S.jsx)(ne,{className:`h-24`}),Q?.linhas.map(e=>(0,S.jsx)(`div`,{children:ie(de,t=>{let n=t.attribs;if(`data-pagamentos-link`in n)return(0,S.jsxs)(_,{className:n.class,to:`/nfts/$nftId`,params:{nftId:e.nftId},children:[(0,S.jsx)(`img`,{src:e.imagem,alt:e.nome,className:`h-[55px] w-[55px] shrink-0 rounded-[5px] object-cover max-[420px]:h-[48px] max-[420px]:w-[48px]`}),(0,S.jsxs)(`span`,{className:`min-w-0`,children:[(0,S.jsx)(`strong`,{className:`block truncate text-[11px] font-bold`,children:e.nome}),(0,S.jsxs)(`small`,{className:`mt-1 block text-[9px] text-kurio-secundaria`,children:[`Edição `,e.edicao]})]})]});if(`data-pagamentos-imagem`in n)return d(t,{src:e.imagem,alt:e.nome});if(`data-pagamentos-nome`in n)return d(t,{},e.nome);if(`data-pagamentos-token`in n||`data-pagamentos-edicao`in n)return d(t,{},`Edição: ${e.edicao} · Qtd. ${e.quantidade}`);if(`data-pagamentos-quantidade`in n)return d(t,{},`(x `+e.quantidade+`)`);if(`data-pagamentos-valor`in n)return d(t,{},v(e.total))})},e.nftId+e.edicaoId))]}));if(r===`pagamentos-sem-itens`)return d(e,f(t,!Q||!!Q.linhas.length),n());if(r===`pagamentos-abrir-cupom`)return d(e,{onClick:()=>M(!j),"aria-expanded":j},n());if(r===`pagamentos-formulario-cupom`){let r=f(t,!j);return d(e,{...r,className:r.className+(j?` flex`:``),onSubmit:e=>{e.preventDefault(),J.mutate({acao:`cupom`,codigo:String(new FormData(e.currentTarget).get(`codigo`))})}},n())}if(r===`pagamentos-cupom`)return d(e,{name:`codigo`,defaultValue:Q?.cupom??``});if(r===`pagamentos-mensagem-cupom`)return d(e,{},J.error?l(J.error).mensagem:Q?.cupom?`Cupom `+Q.cupom+` aplicado.`:``);if(i===`pagamentos-radio-carteira`)return d(e,{defaultChecked:void 0,checked:D===e.attribs.value,disabled:!!k,onChange:()=>O(e.attribs.value)});if(e.name===`label`&&e.children.some(e=>e.type===`tag`&&`attribs`in e&&e.attribs.name===`pagamentos-radio-carteira`)){let t=e.children.find(e=>e.type===`tag`&&`attribs`in e&&e.attribs.name===`pagamentos-radio-carteira`),r=t&&`attribs`in t?t.attribs.value:``;return d(e,{},(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`span`,{className:`checkout-mobile-provedor`,"aria-hidden":`true`,children:r===`Coinbase Wallet`?`◉`:r[0]}),(0,S.jsx)(`span`,{className:`checkout-mobile-provedor-nome`,children:r}),(0,S.jsx)(`span`,{className:`checkout-desktop-provedor`,children:n()}),(0,S.jsx)(`input`,{className:`checkout-mobile-radio`,type:`radio`,"aria-label":r,name:`provedor-mobile`,checked:D===r,disabled:!!k,onChange:()=>O(r)})]}))}if(r===`pagamentos-titulo-perfil`)return d(e,{className:t.className+` checkout-desktop-perfil-titulo`},n());if(r===`pagamentos-titulo-resumo`)return d(e,{className:t.className+` checkout-desktop-resumo-titulo`},n());if(r===`pagamentos-abrir-cupom`)return d(e,{onClick:()=>M(!j),"aria-expanded":j},n());if(r===`pagamentos-confirmar`)return d(e,{disabled:!Q?.linhas.length||!!Q.problemas.length||!W||Y.isPending||X.isPending||!!V||!!q.data},n());if(r===`pagamentos-retorno`){let n=pe||Q?.problemas.join(` `)||(Y.error?l(Y.error).mensagem:``);return d(e,{...f(t,!n),role:n?`alert`:`status`},(0,S.jsxs)(S.Fragment,{children:[n,Object.entries(F).map(([e,t])=>(0,S.jsx)(`span`,{className:`block`,id:L+e,children:t},e))]}))}if(r===`pagamentos-ver-demo`)return(0,S.jsx)(S.Fragment,{})},extras:(0,S.jsxs)(S.Fragment,{children:[(0,S.jsxs)(`div`,{className:`mx-auto max-w-[1200px] px-8`,children:[(0,S.jsx)(te,{erro:Z.error||q.error||K.error||m.error||X.error}),V?.pedidoId?(0,S.jsx)(_,{className:`link`,to:`/pedidos/$pedidoId`,params:{pedidoId:V.pedidoId},children:`Acompanhar pedido`}):V&&!Z.isPending&&(0,S.jsx)(h,{onClick:()=>_e(V),children:`Consultar ou reenviar tentativa`}),q.data&&!V?.pedidoId&&(0,S.jsx)(_,{className:`link`,to:`/pedidos/$pedidoId`,params:{pedidoId:q.data.id},children:`Abrir pedido pendente`}),!W&&m.isSuccess&&(0,S.jsx)(_,{className:`link`,to:`/conta/carteiras`,children:`Cadastre uma carteira para continuar`})]}),(0,S.jsxs)(p,{titulo:`Carteiras cadastradas`,descricao:`Escolha a carteira que receberá os NFTs.`,aberta:me,aoMudar:R,children:[m.data?.map(e=>(0,S.jsxs)(h,{className:`my-2 block w-full`,variant:`outline`,onClick:()=>{ge(e),R(!1)},children:[e.nome,` · `,e.rede]},e.id)),(0,S.jsx)(_,{className:`link`,to:`/conta/carteiras`,children:`Gerenciar carteiras`})]}),(0,S.jsx)(p,{titulo:`Revisar compra`,descricao:`Confira os itens e valores da cotação.`,aberta:!!z,aoMudar:e=>{!e&&!Z.isPending&&B(void 0)},children:z&&(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`ul`,{className:`mb-4`,children:z.cotacao.linhas.map(e=>(0,S.jsxs)(`li`,{children:[e.quantidade,` × `,e.nome]},e.nftId+e.edicaoId))}),(0,S.jsx)(re,{cotacao:z.cotacao}),ye&&(0,S.jsx)(`p`,{role:`alert`,className:`aviso-erro`,children:`A cotação mudou. Feche e revise os valores atualizados.`}),(0,S.jsx)(te,{erro:Z.error}),(0,S.jsx)(h,{disabled:ye||Z.isPending||K.isFetching,onClick:()=>_e(V??{chave:crypto.randomUUID(),proposta:z.proposta}),children:`Confirmar compra`})]})})]})})}export{w as PagamentoVisual};
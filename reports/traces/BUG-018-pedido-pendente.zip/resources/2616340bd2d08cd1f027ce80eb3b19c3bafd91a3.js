import{a as e}from"./rolldown-runtime-BWaJ3C7D.js";import{A as t,B as n,D as r,K as i,P as a,b as o,j as s,k as c,lt as l,n as u,o as d,r as f,t as p,v as m,x as h}from"./Referencia-D6jzv0vf.js";var g={name:`eye`,size:24,node:[[`path`,{d:`M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0`,key:`1nclc0`}],[`circle`,{cx:`12`,cy:`12`,r:`3`,key:`1v7zrd`}]]};g.node;var _=m(g),v={name:`eye-off`,size:24,node:[[`path`,{d:`M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49`,key:`ct8e1f`}],[`path`,{d:`M14.084 14.158a3 3 0 0 1-4.242-4.242`,key:`151rxh`}],[`path`,{d:`M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143`,key:`13bj9a`}],[`path`,{d:`m2 2 20 20`,key:`1ooewy`}]]};v.node;var y=m(v),b=e(l(),1),x=`<!doctype html>
<html lang="pt-BR">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>KURIO — Entrar ou criar conta</title>

    <!-- Tailwind CSS v4 para o protótipo HTML. -->
    <script src="https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4"><\/script>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@400;500;600;700&display=swap" rel="stylesheet" />
    <style type="text/tailwindcss">
      @theme {
        --font-kurio: "Roboto Mono", monospace;
        --color-kurio-fundo: #150e0b;
        --color-kurio-painel: #271914;
        --color-kurio-campo: #291914;
        --color-kurio-texto: #f5f1eb;
        --color-kurio-destaque: #d9904b;
        --color-kurio-secundaria: #ba9a7c;
        --color-kurio-borda: #503022;
      }
    </style>
  </head>

  <body class="m-0 min-h-screen bg-kurio-painel font-kurio text-kurio-texto">
    <!-- O enquadramento e a sombra do modal ficam na página principal. -->
    <main id="login-modal" data-tela="entrar" class="login-modal group relative min-h-[748px] w-full bg-kurio-painel pb-12 data-[tela=cadastro]:min-h-[665px] data-[tela=cadastro]:border-b-[10px] data-[tela=cadastro]:border-b-[#D28A4C] max-[520px]:min-h-screen">

      <!-- FECHAR MODAL -->
      <button
        id="login-fechar"
        type="button"
        class="login-fechar absolute top-4 right-4 z-10 flex h-7 w-7 cursor-pointer items-center justify-center rounded-sm border border-kurio-borda text-kurio-destaque transition-colors hover:border-kurio-destaque hover:bg-[#3b2517] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-kurio-destaque"
        aria-label="Fechar janela de acesso"
      >
        <svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round">
          <path d="M5 5l14 14M19 5L5 19" />
        </svg>
      </button>

      <!-- CENTRALIZAÇÃO INTERNA (largura correspondente ao print) -->
      <div class="login-conteudo mx-auto w-full max-w-[470px] px-6 pt-[56px] max-[520px]:px-5 max-[520px]:pt-[72px]">

        <!-- ABAS -->
        <nav role="tablist" class="login-abas flex items-center justify-center gap-[9px] text-[24px] leading-[1.3] font-bold max-[520px]:text-[20px]" aria-label="Acesso à conta">
          <button
            id="login-aba-entrar"
            type="button"
            data-aba="entrar"
            data-selecionada="true"
            role="tab"
            aria-selected="true"
            aria-controls="login-painel-entrar"
            class="login-aba cursor-pointer text-kurio-texto transition-colors hover:text-kurio-destaque data-[selecionada=true]:text-kurio-destaque focus-visible:outline-2 focus-visible:outline-kurio-destaque"
          >Entrar</button>
          <span class="text-kurio-destaque" aria-hidden="true">|</span>
          <button
            id="login-aba-cadastro"
            type="button"
            data-aba="cadastro"
            data-selecionada="false"
            role="tab"
            aria-selected="false"
            aria-controls="login-painel-cadastro"
            class="login-aba cursor-pointer text-kurio-texto transition-colors hover:text-kurio-destaque data-[selecionada=true]:text-kurio-destaque focus-visible:outline-2 focus-visible:outline-kurio-destaque"
          >Criar conta</button>
        </nav>

        <p id="login-apresentacao" class="login-apresentacao mx-auto mt-[44px] mb-[30px] max-w-[440px] text-center text-[15px] leading-[1.45] group-data-[tela=cadastro]:mt-[26px] group-data-[tela=cadastro]:mb-[22px] group-data-[tela=cadastro]:max-w-[410px] group-data-[tela=cadastro]:text-[13px] group-data-[tela=cadastro]:leading-[1.25] max-[520px]:text-[13px]">
          Entre para gerenciar sua carteira, coleção e perfil de criador.
        </p>

        <!-- ENTRAR -->
        <section id="login-painel-entrar" class="login-painel" role="tabpanel" aria-labelledby="login-aba-entrar">
          <form id="login-formulario-entrar" class="flex flex-col gap-[15px]">
            <label for="login-email" class="sr-only">E-mail</label>
            <input
              id="login-email"
              name="email"
              type="email"
              autocomplete="username"
              placeholder="contato@email.com"
              required
              class="login-campo h-[50px] w-full rounded-[6px] border border-kurio-borda bg-kurio-campo px-5 text-[15px] text-kurio-texto outline-none transition-colors placeholder:text-[#ad8655] hover:border-[#7a4a30] focus:border-kurio-destaque focus:ring-1 focus:ring-kurio-destaque"
            />

            <div class="relative">
              <label for="login-senha" class="sr-only">Senha</label>
              <input
                id="login-senha"
                name="senha"
                type="password"
                autocomplete="current-password"
                placeholder="************"
                minlength="6"
                required
                class="login-campo h-[50px] w-full rounded-[6px] border border-kurio-destaque bg-kurio-campo py-3 pr-14 pl-5 text-[15px] text-kurio-texto outline-none transition-colors placeholder:text-kurio-texto hover:border-[#e6a15f] focus:ring-1 focus:ring-kurio-destaque"
              />
              <button
                type="button"
                data-alternar-senha="login-senha"
                aria-label="Mostrar senha"
                aria-pressed="false"
                class="login-olho absolute top-1/2 right-4 flex h-9 w-9 -translate-y-1/2 cursor-pointer items-center justify-center text-[#bc9558] transition-colors hover:text-kurio-destaque focus-visible:outline-2 focus-visible:outline-kurio-destaque"
              >
                <!-- Ícone de olho riscado -->
                <svg data-olho-fechado viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                  <path d="M3 3l18 18" /><path d="M10.6 5.2a10.7 10.7 0 0 1 1.4-.1c5.1 0 9.1 4 10 6.9a11.8 11.8 0 0 1-3.1 4.5M6.1 6.1A11.5 11.5 0 0 0 2 12c1 3 5 6.9 10 6.9 1.8 0 3.4-.5 4.8-1.3" /><path d="M9.8 9.8a3.2 3.2 0 0 0 4.4 4.4" />
                </svg>
                <!-- Ícone de olho normal -->
                <svg data-olho-aberto hidden class="hidden" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                  <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12Z" /><circle cx="12" cy="12" r="3" />
                </svg>
              </button>
            </div>

            <button type="button" id="login-esqueci" class="self-end cursor-pointer text-[15px] text-kurio-destaque transition-colors hover:underline focus-visible:outline-2 focus-visible:outline-kurio-destaque">
              Esqueceu a senha?
            </button>

            <button type="submit" class="login-botao-primario mt-[15px] h-[56px] w-full cursor-pointer rounded-[5px] bg-kurio-destaque text-[20px] font-bold text-kurio-fundo transition-colors hover:bg-[#e6a15f] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-kurio-destaque">
              Entrar
            </button>
          </form>

          <!-- DIVISOR -->
          <div class="login-divisor mt-[28px] mb-[15px] flex items-center gap-4 text-center text-[14px]">
            <span class="h-px flex-1 bg-[#553325]"></span>
            <span>Ou continue com</span>
            <span class="h-px flex-1 bg-[#553325]"></span>
          </div>

          <!-- LOGIN SOCIAL (VISUAL; a integração real é posterior) -->
          <div class="login-sociais flex flex-col gap-[15px]">
            <button type="button" data-provedor="Google" class="login-social flex h-[50px] w-full cursor-pointer items-center justify-center gap-3 rounded-[6px] border border-kurio-borda bg-kurio-campo text-[14px] font-semibold text-kurio-secundaria transition-colors hover:border-kurio-destaque hover:bg-[#342018] focus-visible:outline-2 focus-visible:outline-kurio-destaque">
              <svg aria-hidden="true" width="25" height="25" viewBox="0 0 48 48">
                <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
                <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.24 5.48-4.73 7.18l7.73 6C44.45 38.03 46.98 31.88 46.98 24.55z"/>
                <path fill="#FBBC05" d="M10.53 28.59A14.4 14.4 0 0 1 9.75 24c0-1.59.27-3.13.77-4.59l-7.98-6.2A23.9 23.9 0 0 0 0 24c0 3.87.93 7.54 2.56 10.78l7.97-6.19z"/>
                <path fill="#34A853" d="M24 48c6.48 0 11.92-2.13 15.89-5.8l-7.73-6c-2.14 1.44-4.87 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.97 6.19C6.51 42.62 14.62 48 24 48z"/>
              </svg>
              Continuar com Google
            </button>
            <button type="button" data-provedor="Facebook" class="login-social flex h-[50px] w-full cursor-pointer items-center justify-center gap-3 rounded-[6px] border border-kurio-borda bg-kurio-campo text-[14px] font-semibold text-kurio-secundaria transition-colors hover:border-kurio-destaque hover:bg-[#342018] focus-visible:outline-2 focus-visible:outline-kurio-destaque">
              <svg aria-hidden="true" width="24" height="24" viewBox="0 0 24 24" fill="#4267B2"><path d="M16.4 8H14V6.5c0-.7.5-.9.9-.9h1.5V3h-2.1C11.7 3 11 4.7 11 6.4V8H9v2.8h2V21h3V10.8h2.1L16.4 8z"/></svg>
              Continuar com Facebook
            </button>
          </div>
        </section>

        <!-- CRIAR CONTA: LAYOUT FIEL AO FIGMA, COM TAILWIND CSS -->
        <section id="login-painel-cadastro" class="login-painel hidden" hidden role="tabpanel" aria-labelledby="login-aba-cadastro">
          <form id="login-formulario-cadastro" class="mx-auto flex w-full max-w-[344px] flex-col gap-[13px]">
            <label for="login-nome" class="sr-only">Nome de usuário</label>
            <input
              id="login-nome"
              name="nome"
              type="text"
              autocomplete="username"
              placeholder="Nome de usuário"
              minlength="2"
              required
              class="cadastro-campo h-[40px] w-full rounded-[6px] border border-kurio-borda bg-kurio-campo px-[15px] text-[13px] text-kurio-texto outline-none transition-colors placeholder:text-[#ad8655] focus:border-kurio-destaque focus:ring-1 focus:ring-kurio-destaque"
            />

            <label for="login-email-cadastro" class="sr-only">E-mail</label>
            <input
              id="login-email-cadastro"
              name="email"
              type="email"
              autocomplete="email"
              placeholder="Digite seu e-mail"
              required
              class="cadastro-campo h-[40px] w-full rounded-[6px] border border-kurio-borda bg-kurio-campo px-[15px] text-[13px] text-kurio-texto outline-none transition-colors placeholder:text-[#ad8655] focus:border-kurio-destaque focus:ring-1 focus:ring-kurio-destaque"
            />

            <div class="relative">
              <label for="login-senha-cadastro" class="sr-only">Senha</label>
              <input
                id="login-senha-cadastro"
                name="senha"
                type="password"
                autocomplete="new-password"
                placeholder="Senha"
                minlength="8"
                required
                class="cadastro-campo h-[40px] w-full rounded-[6px] border border-kurio-borda bg-kurio-campo py-2 pr-11 pl-[15px] text-[13px] text-kurio-texto outline-none transition-colors placeholder:text-[#ad8655] focus:border-kurio-destaque focus:ring-1 focus:ring-kurio-destaque"
              />
              <button
                type="button"
                data-alternar-senha="login-senha-cadastro"
                aria-label="Mostrar senha"
                aria-pressed="false"
                class="cadastro-olho absolute inset-y-0 right-2 flex w-[32px] cursor-pointer items-center justify-center text-[#bc9558] transition-colors hover:text-kurio-destaque focus-visible:outline-2 focus-visible:outline-kurio-destaque"
              >
                <!-- Ícone único: nunca some ao mostrar a senha. -->
                <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                  <path d="M3 3l18 18" />
                  <path d="M10.6 5.2a10.7 10.7 0 0 1 1.4-.1c5.1 0 9.1 4 10 6.9a11.8 11.8 0 0 1-3.1 4.5M6.1 6.1A11.5 11.5 0 0 0 2 12c1 3 5 6.9 10 6.9 1.8 0 3.4-.5 4.8-1.3" />
                  <path d="M9.8 9.8a3.2 3.2 0 0 0 4.4 4.4" />
                </svg>
              </button>
            </div>

            <label for="login-confirmar-senha" class="sr-only">Confirmar senha</label>
            <input
              id="login-confirmar-senha"
              name="confirmacao"
              type="password"
              autocomplete="new-password"
              placeholder="Confirmar senha"
              minlength="8"
              required
              class="cadastro-campo h-[40px] w-full rounded-[6px] border border-kurio-borda bg-kurio-campo px-[15px] text-[13px] text-kurio-texto outline-none transition-colors placeholder:text-[#ad8655] focus:border-kurio-destaque focus:ring-1 focus:ring-kurio-destaque"
            />

            <button
              type="submit"
              class="cadastro-botao mt-[11px] h-[46px] w-full cursor-pointer rounded-[5px] bg-[#D28A4C] text-[16px] font-bold text-kurio-fundo transition-colors hover:bg-[#e6a15f] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-kurio-destaque"
            >Criar conta</button>
          </form>

          <div class="cadastro-divisor mx-auto mt-[29px] mb-[15px] flex w-full max-w-[344px] items-center gap-3 text-center text-[13px]">
            <span class="h-px flex-1 bg-[#553325]"></span>
            <span class="shrink-0">Ou continue com</span>
            <span class="h-px flex-1 bg-[#553325]"></span>
          </div>

          <div class="cadastro-sociais mx-auto flex w-full max-w-[344px] flex-col gap-[15px]">
            <button type="button" data-provedor="Google" class="cadastro-social flex h-[40px] w-full cursor-pointer items-center justify-center gap-3 rounded-[6px] border border-kurio-borda bg-kurio-campo text-[13px] font-semibold text-kurio-secundaria transition-colors hover:border-kurio-destaque hover:bg-[#342018] focus-visible:outline-2 focus-visible:outline-kurio-destaque">
              <svg aria-hidden="true" width="22" height="22" viewBox="0 0 48 48">
                <path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/>
                <path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.24 5.48-4.73 7.18l7.73 6C44.45 38.03 46.98 31.88 46.98 24.55z"/>
                <path fill="#FBBC05" d="M10.53 28.59A14.4 14.4 0 0 1 9.75 24c0-1.59.27-3.13.77-4.59l-7.98-6.2A23.9 23.9 0 0 0 0 24c0 3.87.93 7.54 2.56 10.78l7.97-6.19z"/>
                <path fill="#34A853" d="M24 48c6.48 0 11.92-2.13 15.89-5.8l-7.73-6c-2.14 1.44-4.87 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.97 6.19C6.51 42.62 14.62 48 24 48z"/>
              </svg>
              Continuar com Google
            </button>
            <button type="button" data-provedor="Facebook" class="cadastro-social flex h-[40px] w-full cursor-pointer items-center justify-center gap-3 rounded-[6px] border border-kurio-borda bg-kurio-campo text-[13px] font-semibold text-kurio-secundaria transition-colors hover:border-kurio-destaque hover:bg-[#342018] focus-visible:outline-2 focus-visible:outline-kurio-destaque">
              <svg aria-hidden="true" width="22" height="22" viewBox="0 0 24 24" fill="#4267B2"><path d="M16.4 8H14V6.5c0-.7.5-.9.9-.9h1.5V3h-2.1C11.7 3 11 4.7 11 6.4V8H9v2.8h2V21h3V10.8h2.1L16.4 8z"/></svg>
              Continuar com Facebook
            </button>
          </div>
        </section>

        <!-- RECUPERAÇÃO DE SENHA: VISUAL -->
        <section id="login-painel-recuperar" class="login-painel hidden" hidden>
          <form id="login-formulario-recuperar" class="flex flex-col gap-4">
            <label for="login-email-recuperar" class="sr-only">E-mail da conta</label>
            <input id="login-email-recuperar" type="email" autocomplete="email" placeholder="contato@email.com" required class="h-[50px] w-full rounded-[6px] border border-kurio-borda bg-kurio-campo px-5 text-[15px] outline-none placeholder:text-[#ad8655] focus:border-kurio-destaque focus:ring-1 focus:ring-kurio-destaque" />
            <button type="submit" class="mt-2 h-[56px] w-full cursor-pointer rounded-[5px] bg-kurio-destaque text-[17px] font-bold text-kurio-fundo hover:bg-[#e6a15f]">Solicitar recuperação</button>
            <button id="login-voltar" type="button" class="self-center cursor-pointer text-[13px] text-kurio-destaque hover:underline">Voltar para entrar</button>
          </form>
        </section>

        <!-- AÇÕES NÃO PERSISTEM USUÁRIO NESTE PROTÓTIPO -->
        <p id="login-aviso" class="login-aviso mt-6 hidden rounded-[5px] border border-kurio-destaque/40 bg-[#3b2517] px-3 py-3 text-center text-[12px] leading-5 text-kurio-secundaria" role="status" aria-live="polite" hidden></p>

      </div>
    </main>
    <script src="./interacoes.js" defer><\/script>
  </body>
</html>
`,S=i(),C=f(`login`,x);function w({acao:e,retorno:i}){let l=e===`cadastro`,[f,m]=(0,b.useState)(!1),[g,v]=(0,b.useState)({}),[x,w]=(0,b.useState)(``),T=n(),{avisar:E}=o(),D=a({mutationFn:n=>t.autenticar(e,{...n,confirmarSenha:n.confirmacao}),onSuccess:async e=>{await r(),s(e.token),h.setQueryData([`sessao`],e),E(e.avisos.join(` `)),await T({href:i,replace:!0})}}),O=f?`recuperar`:l?`cadastro`:`entrar`,k=D.isError?c(D.error):void 0;return(0,S.jsx)(p,{pagina:C,alterar:(e,t,n)=>{let r=e.attribs.id;if(r===`login-modal`)return u(e,{"data-tela":O},(0,S.jsxs)(S.Fragment,{children:[n(),(0,S.jsx)(`button`,{type:`button`,className:`referencia-alternar-login`,onClick:()=>void T({to:l?`/login`:`/cadastro`,search:{retorno:i}}),children:l?`Já tem uma conta? Entre`:`Novo na Kurio? Crie uma conta`})]}));if(r?.startsWith(`login-painel-`))return u(e,d(t,!r.endsWith(O)),n());if(r===`login-apresentacao`)return u(e,{},f?`Informe seu e-mail para recuperar o acesso à sua conta.`:l?`Crie seu perfil de colecionador e conecte uma carteira quando quiser.`:n());if(e.attribs[`data-aba`]){let t=e.attribs[`data-aba`];return u(e,{"data-selecionada":String(O===t),"aria-selected":O===t,onClick:()=>{m(!1),w(``),D.reset(),T({to:t===`cadastro`?`/cadastro`:`/login`,search:{retorno:i},replace:!0})}},t===`cadastro`?(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`span`,{className:`cadastro-desktop-texto`,children:n()}),(0,S.jsx)(`span`,{className:`cadastro-mobile-texto`,children:`Criar perfil de colecionador`})]}):n())}if(r===`login-fechar`)return u(e,{onClick:()=>void T({to:`/`})},n());if(r===`login-esqueci`||r===`login-voltar`)return u(e,{onClick:()=>{w(``),D.reset(),m(r===`login-esqueci`)}},n());if(r===`login-formulario-entrar`||r===`login-formulario-cadastro`)return u(e,{noValidate:!1,onSubmit:e=>{e.preventDefault(),w(``),D.mutate(Object.fromEntries(new FormData(e.currentTarget)))}},n());if(r===`login-formulario-recuperar`)return u(e,{onSubmit:e=>{e.preventDefault(),w(`A recuperação por e-mail está indisponível na demonstração.`)}},n());if(e.attribs[`data-provedor`])return u(e,{onClick:()=>{D.reset(),w(`O acesso por `+e.attribs[`data-provedor`]+` está indisponível na demonstração.`)}},n());if(e.attribs[`data-alternar-senha`]){let t=e.attribs[`data-alternar-senha`];return u(e,{"aria-pressed":!!g[t],onClick:()=>v(e=>({...e,[t]:!e[t]}))},n())}if(e.name===`input`&&r){let n=e.attribs.name===`confirmacao`?`confirmarSenha`:e.attribs.name,i=k?.campos?.[n],a=n===`nome`?`Nome de usuário`:n===`email`?`E-mail`:n===`confirmarSenha`?`Confirmar senha`:n===`senha`?`Senha`:void 0,o=u(e,{type:g[r]?`text`:t.type,"aria-label":a,"aria-invalid":!!i,"aria-describedby":i?`login-aviso`:void 0});return r===`login-confirmar-senha`?(0,S.jsxs)(`div`,{className:`confirmar-senha-mobile`,children:[o,(0,S.jsx)(`button`,{className:`cadastro-olho absolute inset-y-0 right-2 w-8 items-center justify-center text-[#bc9558]`,type:`button`,"aria-label":g[r]?`Ocultar confirmação de senha`:`Mostrar confirmação de senha`,"aria-pressed":!!g[r],onClick:()=>v(e=>({...e,[r]:!e[r]})),children:g[r]?(0,S.jsx)(_,{"aria-hidden":`true`}):(0,S.jsx)(y,{"aria-hidden":`true`})})]}):o}if(e.name===`button`&&e.attribs.type===`submit`){let t=e.parent?.type===`tag`&&`attribs`in e.parent&&e.parent.attribs.id===`login-formulario-cadastro`;return u(e,{disabled:D.isPending},t?(0,S.jsxs)(S.Fragment,{children:[(0,S.jsx)(`span`,{className:`cadastro-desktop-texto`,children:n()}),(0,S.jsx)(`span`,{className:`cadastro-mobile-texto`,children:`Criar perfil`})]}):n())}if(r===`login-aviso`)return u(e,{...d(t,!x&&!k),role:k?`alert`:`status`},x||(k?.campos?Object.values(k.campos).join(` `):k?.mensagem??``))},extras:(0,S.jsx)(`h1`,{className:`sr-only`,children:l?`Criar perfil de colecionador`:`Entrar`})})}export{w as AutenticacaoVisual};